import unittest

from selenium import webdriver
from selenium.webdriver.common.keys import Keys

from   selenium.webdriver.support.select import Select
from   selenium.webdriver.common.by import By
from   selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support.ui import Select
#from selenium.webdriver.common.exceptions import TimeoutException
# Set Selenium firefox browser object
browser = webdriver.Chrome()
# Step 1: Navigate to page
browser.get("http://www.moviefone.com")

#Navigating the Menu item for Movies
#movies = browser.find_element_by_name("movies")
#movies =browser.find_element_by_class_name("dropdown-button homepage_topnav_link_new_movie_releases")
#mySelect = Select(browser.find_element_by_name('movies'))
#mySelect.select_by_index(1)
#movies.click()

#movie2 works Find movie on grid layout
movie2 = browser.find_element_by_class_name("homepage__li_3")
movie2.click()

browser.back()
WebDriverWait (browser,3)

#movie 4 works Find movie on grid layout
movie4 = browser.find_element_by_class_name("homepage__li_4")
movie4.click()

#Rating works
#rating = browser.find_element_by_class_name("arrow")
#rating.click()
#value1 = rating.get_attribute("value1")
#rating.

#<a href="#" class="aol-feedback-plugin-link" data-client="moviefone_en_us" data-dev-id="ao19852k0fksIu">feedback</a>

feedback = browser.find_element_by_class_name ("aol-feedback-plugin-link")
feedback.click()
#change to terms of service and come back

#zipcode = browser.find_element_by_id("location")
#zipcode.send_keys("10001");
#zipcode.click();

browser.close()
