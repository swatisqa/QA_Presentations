import unittest

from selenium import webdriver
from selenium.webdriver.common.keys import Keys

from   selenium.webdriver.support.select import Select
from   selenium.webdriver.common.by import By
from   selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from selenium.webdriver.support.ui import Select
#from selenium.webdriver.common.exceptions import TimeoutException

browser = webdriver.Chrome()
# Step 1: Navigate to page
browser.get("http://www.moviefone.com")

menu = browser.find_element_by_class_name("dropdown-button homepage_topnav_link_dvd")
menu.click()

browser.back()