import unittest

from selenium import webdriver
from selenium.webdriver.common.keys import Keys

from   selenium.webdriver.support.select import Select
from   selenium.webdriver.common.by import By
from   selenium.webdriver.support import expected_conditions as EC

#Sample test of testing Search input box, click on results navigating to menu items
#webdriver.FirefoxProfile
driver = webdriver.Chrome()
driver.get("http://www.moviefone.com")


#find the element that's name attribute is q (the google search box)
#inputElement = driver.find_element_by_name("desktop-placeholder-1")

#inputElement = driver.find_element_by_id("desktop-search")
inputElement = driver.find_element_by_id("desktop-search-input")
# type in the search
inputElement.send_keys("The Boss")
inputElement.send_keys(Keys.RETURN)

driver.back()

#inputElement.clear()
inputElement2 = driver.find_element_by_id("desktop-search-input")
inputElement2.send_keys("Star Wars")
inputElement2.send_keys(Keys.RETURN)

rbutton = driver.find_element_by_class_name("red button")
#rbutton = driver.find_element_by_xpath("//*[@id="search-movie-bucket"]/div[2]/div[1]/a[2]")
rbutton.click()
#print (driver.title)

driver.back()

#Selection option in Movie dropdown
mySelect = Select(driver.find_element_by_name("movies"))
option = mySelect.select_by_visible_text("News")
print (option.text)